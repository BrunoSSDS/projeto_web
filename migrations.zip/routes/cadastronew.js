import express from "express";
import { addcadastronew, deletecadastronew, getcadastronews, updatecadastronew } from "../controllers/cadastronew.js";

const router = express.Router()

router.get("/", getcadastronews)

router.post("/", addcadastronew)

router.put("/:id", updatecadastronew)

router.delete("/:id", deletecadastronew)

export default router